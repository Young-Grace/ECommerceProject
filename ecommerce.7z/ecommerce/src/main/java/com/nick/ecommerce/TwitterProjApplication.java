package com.nick.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwitterProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwitterProjApplication.class, args);
	}

}
